# MaPUC — Campus Wayfinding PUC-Rio

App mobile-first que reproduz as 9 telas enviadas, com navegação e interatividade funcionando de ponta a ponta.

## Identidade visual
- Azul-marinho profundo para textos, cabeçalhos e botões escuros.
- Teal/verde-água para os botões principais ("Acessar Mapa", "Salvar alterações", "Ir Agora", "Rotear").
- Fundo cinza-azulado bem claro, cartões brancos com cantos arredondados e sombra suave.
- Vermelho apenas para sair da conta e alertas.
- Tipografia sem serifa, títulos em negrito e caixa alta como nos mockups.
- O app é enquadrado como celular; em telas grandes aparece centralizado com um seletor para alternar entre visão mobile e desktop.

## Telas e navegação
1. **Login** — logo MaPUC, campos matrícula/e-mail e senha com olho de mostrar/ocultar, botão "Acessar Mapa", "Esqueceu sua senha?" e "Não tem cadastro?".
2. **Cadastro** — nome, e-mail, CEP com busca automática de endereço, seletor de curso da PUC-Rio, matrícula, senha com checagem ao vivo dos critérios (8 caracteres, 2 símbolos, 1 número), confirmação e caixas de aceite. "Próximo" abre a verificação.
3. **Código por e-mail** — janela sobreposta com 4 campos, avanço automático entre eles, contagem regressiva de 60 segundos, reenviar código e confirmar.
4. **Início** — busca de salas, blocos e serviços com sugestões; cartão "Próxima aula hoje" com botão "Rotear"; atalhos (Biblioteca, Alimentação); gaveta lateral de menu; barra inferior Mapa / Horário.
5. **Mapa do campus (Gávea)** — mapa estilizado e interativo com os prédios principais (Cardeal Leme, Cardeal Frings, RDC, Padre Leonel Franca, Vila dos Diretórios, Pilotis, Ginásio, Biblioteca Central). Tocar num prédio mostra seus dados; "Rotear" desenha o caminho a pé do ponto atual até a sala, com andar e instruções passo a passo.
6. **Horário** — grade semanal Seg–Sex nas faixas 07-09, 09-11, 11-13, 14-16, 16-18, com chips coloridos das disciplinas (INF1005/L318, MAT1161/K102 e L206, ENG1000/F402, FIS1025/L112, LET1010/R204). Banner de instrução e banner da aula de hoje com "Ir Agora". Tocar numa aula abre os detalhes; tocar na sala vai direto ao mapa.
7. **Detalhes da aula** — código, nome, tipo (obrigatória/eletiva), horário, turma, professor e sala, com "Ver rota até a sala" abrindo o mapa já focado.
8. **Avisos e recados** — central de notificações com trocas de sala, cancelamentos e recados de professores; alertas em destaque, marcar como lido e botão para atualizar a rota.
9. **Perfil / Dados / Senha / Sair** — perfil da conta acadêmica com atalhos; edição de dados com foto ou iniciais; alteração de senha; confirmação de logout em tela própria.

## Dados
Nesta primeira versão os dados (aluno, disciplinas, prédios, avisos) ficam no próprio app, em memória, com as informações exatas dos mockups. As edições de perfil e a leitura de avisos valem durante a sessão. Login e cadastro são simulados — qualquer credencial entra.

Se você quiser contas reais, senhas guardadas com segurança e horários salvos entre dispositivos, posso ativar o backend depois.

## Detalhes técnicos
- TanStack Start com rotas separadas: `/` (login), `/cadastro`, `/inicio`, `/mapa`, `/horario`, `/aula/$id`, `/avisos`, `/perfil`, `/perfil/dados`, `/perfil/senha`, `/perfil/sair`.
- Estado de sessão e dados via contexto React + `localStorage`; guarda de rota redireciona ao login.
- Tokens de cor/raio adicionados em `src/styles.css` (oklch), sem cores fixas nos componentes.
- Mapa em SVG próprio com prédios como formas clicáveis e rota animada em `stroke-dasharray`; sem biblioteca de mapas.
- Busca de CEP via ViaCEP com tratamento de erro e preenchimento manual.
- Cada rota com `head()` próprio (título e descrição).
