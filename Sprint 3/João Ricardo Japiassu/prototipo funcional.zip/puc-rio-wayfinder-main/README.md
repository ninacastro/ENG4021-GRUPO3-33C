# Campus Compass

Crie o aplicativo MaPUC (Campus Wayfinding PUC-Rio) reproduzindo com fidelidade o design das 9 telas anexadas e conectando toda a navegação e interatividade funcional.

Principais funcionalidades e telas a implementar:
1. Tela de Login (screen 4): Logo MaPUC, campos de Matrícula/E-mail e Senha, botão 'Acessar Mapa', links de 'Esqueceu sua senha?' e 'Não tem cadastro?'.
2. Cadastro (screen 8): Formulário de registro com Nome completo, E-mail, CEP com busca de endereço, seletor de Curso da PUC-Rio, Matrícula, requisitos dinâmicos de validação de senha, confirmação de senha e termos.
3. Verificação em duas etapas / Código (screen 7): Modal/tela com 4 inputs para código OTP enviado por e-mail, temporizador decrescente, opção de reenviar código e confirmar.
4. Tela Principal / Início (screen 6): Barra de busca de salas, blocos e serviços (ex: L318, Frings, Pilotis, RDC, etc.), card destacado da 'Próxima aula hoje' com botão 'Rotear', atalhos rápidos (Biblioteca, Alimentação na Vila dos Diretórios, etc.), menu lateral / gaveta de navegação e barra inferior (Mapa e Horário).
5. Mapa Interativo do Campus da PUC-Rio (Gávea): Mapa interativo estilizado do campus da PUC-Rio com os principais prédios mapeados (Cardeal Leme, Cardeal Frings, RDC, Padre Leonel Franca, Vila dos Diretórios, Pilotis, Ginásio, Biblioteca Central, etc.). Ao clicar em 'Rotear' ou selecionar uma sala, traçar a rota a pé entre o ponto atual e a sala desejada, com detalhes dos andares e instruções passo a passo.
6. Horário de Aulas / Grade Semestral (screen 5): Tabela semanal interativa (Segunda a Sexta, horários 07-09, 09-11, 11-13, 14-16, 16-18) com chips coloridos para matérias como INF1005 (L318), MAT1161 (K102/L206), ENG1000 (F402), FIS1025 (L112), LET1010 (R204). Banner informativo de clique na sala para rotear e banner de aula em andamento com botão 'Ir Agora'.
7. Detalhes da Aula (screen 2): Exibição do código e nome da disciplina (ex: ENG4021 - PROJETO INTEGRADO - SOFTWARE), tipo (Obrigatória/Eletiva), Horário, Turma, Professor e Sala com botão 'Ver rota até a sala' que leva ao mapa já focado na sala.
8. Sistema de Avisos de Mudança de Sala e Recados: Central de notificações interativa com alertas de trocas repentinas de sala, cancelamento de aula ou recados dos professores, com destaque visual e opção de atualizar a rota automaticamente.
9. Perfil e Ajustes (screen 9 e screen 1): Visualização dos dados da conta acadêmica, tela de alteração de dados com foto/iniciais, formulário de alteração de senha e modal de confirmação de logout (screen 3).

Mantenha a identidade visual idêntica aos mockups (paleta de azuis escuros, teal/verde água nos botões principais, tons suaves de cinza/azul para cartões e inputs elegantes estilo mobile-first). Adicione suporte para alternar visualização mobile e desktop.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://puc-rio-wayfinder.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7589ebcc-1eb6-41e6-9d5b-47867006a278).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
