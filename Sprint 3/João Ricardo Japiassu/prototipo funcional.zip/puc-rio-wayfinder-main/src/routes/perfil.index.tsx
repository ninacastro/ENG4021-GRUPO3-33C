import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, CircleHelp, LogOut, Map as MapIcon, ShieldCheck, SquarePen, UserRound } from "lucide-react";
import { AppFrame } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/perfil/")({
  head: () => ({
    meta: [
      { title: "Perfil — MaPUC PUC-Rio" },
      { name: "description", content: "Dados da sua conta acadêmica no MaPUC: nome, matrícula, curso e ajustes." },
      { property: "og:title", content: "Perfil — MaPUC" },
      { property: "og:description", content: "Conta acadêmica, alteração de dados e suporte do campus." },
    ],
  }),
  component: PerfilPage,
});

const items = [
  {
    to: "/perfil/dados",
    icon: SquarePen,
    title: "ALTERAR DADOS",
    subtitle: "Nome, e-mail, senha e curso",
    tone: "blue",
  },
  {
    to: "/perfil/privacidade",
    icon: ShieldCheck,
    title: "POLÍTICA DE PRIVACIDADE",
    subtitle: "Proteção de dados e localização",
    tone: "muted",
  },
  {
    to: "/perfil/sair",
    icon: LogOut,
    title: "DESLOGAR",
    subtitle: "Encerrar sessão no dispositivo",
    tone: "danger",
  },
  {
    to: "/perfil/ajuda",
    icon: CircleHelp,
    title: "AJUDA",
    subtitle: "Dúvidas frequentes e suporte do campus",
    tone: "warn",
  },
] as const;

const toneBox: Record<string, string> = {
  blue: "bg-brand-blue-soft text-brand-blue",
  muted: "bg-muted text-navy",
  danger: "bg-danger-soft text-danger",
  warn: "bg-warn-soft text-warn",
};

function PerfilPage() {
  const { student } = useApp();

  return (
    <AppFrame>
      <header className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-card px-4 py-4">
        <Link
          to="/inicio"
          aria-label="Voltar ao menu principal"
          className="grid h-9 w-9 place-items-center rounded-full border border-border text-navy hover:bg-muted"
        >
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <span className="mx-auto flex items-center gap-2 rounded-full bg-brand-blue-soft px-4 py-2 text-sm font-bold tracking-wide text-brand-blue">
          <MapIcon className="h-4 w-4" /> PUC MAPA GUIA
        </span>
        <CircleHelp className="h-5 w-5 text-muted-foreground" />
      </header>

      <div className="flex-1 space-y-4 px-4 py-5">
        <section className="card-soft grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 p-5">
          <div className="min-w-0">
            <span className="inline-block rounded-lg bg-brand-blue-soft px-3 py-1 text-xs font-bold tracking-wider text-brand-blue">
              CONTA ACADÊMICA
            </span>
            <h1 className="mt-2 text-3xl font-extrabold text-navy">PERFIL</h1>
            <p className="truncate text-base text-navy">{student.name}</p>
            <p className="truncate font-mono text-sm text-muted-foreground">Matrícula: {student.registration}</p>
          </div>
          <div className="relative grid h-20 w-20 shrink-0 place-items-center rounded-full border-2 border-navy bg-brand-blue-soft text-navy">
            <UserRound className="h-10 w-10" />
            <span className="absolute bottom-1 right-1 h-4 w-4 rounded-full border-2 border-card bg-teal-dark" />
          </div>
        </section>

        {items.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="card-soft grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 p-4"
          >
            <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${toneBox[item.tone]}`}>
              <item.icon className="h-6 w-6" />
            </span>
            <span className="min-w-0">
              <span
                className={`block text-base font-extrabold tracking-wide ${item.tone === "danger" ? "text-danger" : "text-navy"}`}
              >
                {item.title}
              </span>
              <span className="block text-sm text-muted-foreground">{item.subtitle}</span>
            </span>
            <span
              className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${item.tone === "danger" ? "bg-danger-soft text-danger" : "bg-muted text-navy"}`}
            >
              ›
            </span>
          </Link>
        ))}
      </div>

      <footer className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 border-t border-border bg-card px-4 py-4">
        <Link
          to="/inicio"
          className="flex items-center gap-2 rounded-2xl border border-border px-4 py-3 text-sm font-bold tracking-wide text-navy"
        >
          <ArrowLeft className="h-4 w-4" /> VOLTAR
        </Link>
        <span className="text-right text-sm text-muted-foreground">Versão 2.4.1 (Campus)</span>
      </footer>
    </AppFrame>
  );
}
