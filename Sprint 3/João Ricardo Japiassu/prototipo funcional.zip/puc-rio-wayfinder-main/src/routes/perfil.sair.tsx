import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { IdCard, LogOut } from "lucide-react";
import { toast } from "sonner";
import { AppFrame, ScreenHeader } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { initialsOf } from "@/lib/mapuc-data";

export const Route = createFileRoute("/perfil/sair")({
  head: () => ({
    meta: [
      { title: "Deslogar — MaPUC PUC-Rio" },
      { name: "description", content: "Encerre a sessão do MaPUC neste dispositivo com segurança." },
      { property: "og:title", content: "Deslogar — MaPUC" },
      { property: "og:description", content: "Confirme a saída da sua conta acadêmica." },
    ],
  }),
  component: SairPage,
});

function SairPage() {
  const { student, signOut } = useApp();
  const navigate = useNavigate();

  return (
    <AppFrame>
      <ScreenHeader title="Deslogar" back="/perfil" />

      <div className="flex flex-1 flex-col gap-6 px-5 py-6">
        <section className="card-soft grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4 p-4">
          <div className="relative grid h-16 w-16 shrink-0 place-items-center rounded-full bg-navy text-lg font-extrabold text-primary-foreground">
            {initialsOf(student.name)}
            <span className="absolute bottom-0 right-0 h-5 w-5 rounded-full border-2 border-card bg-teal-dark" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-base font-bold text-navy">{student.name}</p>
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <IdCard className="h-4 w-4" /> Matrícula: <span className="font-bold text-navy">{student.registration}</span>
            </p>
            <span className="mt-1 inline-block rounded-md bg-muted px-2 py-0.5 text-xs text-navy">{student.course}</span>
          </div>
        </section>

        <div className="flex flex-col items-center text-center">
          <span className="grid h-16 w-16 place-items-center rounded-2xl bg-danger-soft text-danger">
            <LogOut className="h-8 w-8" />
          </span>
          <h2 className="mt-4 text-xl font-extrabold text-navy">Tem certeza que deseja sair da sua conta?</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Você será desconectado e precisará informar seu cadastro e senha para acessar o MaPUC novamente.
          </p>
        </div>

        <div className="mt-auto space-y-3">
          <button
            type="button"
            onClick={() => {
              signOut();
              toast.success("Sessão encerrada.");
              navigate({ to: "/", replace: true });
            }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-danger py-4 text-base font-bold text-primary-foreground"
          >
            <LogOut className="h-5 w-5" /> Sair
          </button>
          <Link
            to="/perfil"
            className="block w-full rounded-2xl border border-border bg-card py-4 text-center text-base font-semibold text-navy"
          >
            Cancelar
          </Link>
        </div>
      </div>
    </AppFrame>
  );
}
