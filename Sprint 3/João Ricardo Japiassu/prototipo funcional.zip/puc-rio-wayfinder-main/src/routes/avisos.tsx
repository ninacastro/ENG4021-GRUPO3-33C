import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { BellRing, CalendarX2, Check, MessageSquareText, Navigation } from "lucide-react";
import { toast } from "sonner";
import { AppFrame, BottomNav, ScreenHeader } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { CLASSES, type Notice } from "@/lib/mapuc-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/avisos")({
  head: () => ({
    meta: [
      { title: "Avisos e recados — MaPUC PUC-Rio" },
      { name: "description", content: "Trocas de sala, cancelamentos e recados dos professores, com rota atualizada." },
      { property: "og:title", content: "Avisos e recados — MaPUC" },
      { property: "og:description", content: "Central de notificações do campus da PUC-Rio." },
    ],
  }),
  component: AvisosPage,
});

const kindStyle: Record<Notice["kind"], { icon: typeof BellRing; box: string; chip: string; label: string }> = {
  sala: {
    icon: BellRing,
    box: "border-warn/40 bg-warn-soft",
    chip: "bg-warn/20 text-navy",
    label: "Mudança de sala",
  },
  cancelamento: {
    icon: CalendarX2,
    box: "border-danger/30 bg-danger-soft",
    chip: "bg-danger/15 text-danger",
    label: "Cancelamento",
  },
  recado: {
    icon: MessageSquareText,
    box: "border-border bg-card",
    chip: "bg-brand-blue-soft text-brand-blue",
    label: "Recado",
  },
};

function AvisosPage() {
  const navigate = useNavigate();
  const { notices, readIds, markRead, markAllRead, applyRoomChange, roomOverrides } = useApp();

  return (
    <AppFrame>
      <ScreenHeader
        title="Avisos e recados"
        right={
          <button
            type="button"
            onClick={() => {
              markAllRead();
              toast.success("Todos os avisos foram marcados como lidos.");
            }}
            className="rounded-full bg-muted px-3 py-1.5 text-xs font-bold text-navy"
          >
            Marcar tudo
          </button>
        }
      />

      <div className="flex-1 space-y-3 px-4 py-4">
        {notices.map((n) => {
          const style = kindStyle[n.kind];
          const read = readIds.includes(n.id);
          const lesson = n.classId ? CLASSES.find((c) => c.id === n.classId) : undefined;
          const applied = lesson ? roomOverrides[lesson.id] === n.newRoom : false;
          return (
            <article key={n.id} className={cn("rounded-2xl border p-4", style.box, read && "opacity-70")}>
              <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-start gap-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-card text-navy">
                  <style.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0">
                  <span className={cn("inline-block rounded-md px-2 py-0.5 text-[11px] font-bold", style.chip)}>
                    {style.label}
                  </span>
                  <h2 className="mt-1 truncate text-base font-bold text-navy">{n.title}</h2>
                  <p className="mt-1 text-sm text-navy/80">{n.message}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{n.meta}</p>
                </div>
                {!read ? (
                  <button
                    type="button"
                    aria-label="Marcar como lido"
                    onClick={() => markRead(n.id)}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-card text-teal-dark"
                  >
                    <Check className="h-4 w-4" />
                  </button>
                ) : null}
              </div>

              {n.newRoom && lesson ? (
                <button
                  type="button"
                  onClick={() => {
                    applyRoomChange(lesson.id, n.newRoom!);
                    markRead(n.id);
                    toast.success(`Rota atualizada para a sala ${n.newRoom}.`);
                    navigate({ to: "/mapa", search: { sala: n.newRoom! } });
                  }}
                  className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-3 text-sm font-bold text-primary-foreground"
                >
                  <Navigation className="h-4 w-4 text-teal" />
                  {applied ? `Ver rota até ${n.newRoom}` : "Atualizar rota automaticamente"}
                </button>
              ) : null}
            </article>
          );
        })}
      </div>

      <BottomNav />
    </AppFrame>
  );
}
