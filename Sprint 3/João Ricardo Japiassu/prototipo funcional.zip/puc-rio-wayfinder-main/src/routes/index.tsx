import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Eye, EyeOff, ExternalLink, Lock, UserPlus, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { MapucWordmark } from "@/components/mapuc/Logo";
import { AppFrame } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar no MaPUC — Campus Wayfinding PUC-Rio" },
      { name: "description", content: "Acesse o MaPUC com suas credenciais acadêmicas da PUC-Rio e encontre sua sala." },
      { property: "og:title", content: "Entrar no MaPUC" },
      { property: "og:description", content: "Acesse com as credenciais acadêmicas da PUC-Rio." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { signIn, signedIn, hydrated } = useApp();
  const navigate = useNavigate();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (hydrated && signedIn) navigate({ to: "/inicio", replace: true });
  }, [hydrated, signedIn, navigate]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!identifier.trim() || password.length < 4) {
      toast.error("Informe seu cadastro e uma senha válida.");
      return;
    }
    signIn(identifier);
    navigate({ to: "/inicio" });
  }

  return (
    <AppFrame requireAuth={false}>
      <div className="flex flex-1 flex-col px-6 pt-10">
        <MapucWordmark />
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Acesse com as credenciais acadêmicas da PUC-Rio
        </p>

        <form onSubmit={submit} className="mt-8 space-y-5">
          <div>
            <div className="flex items-baseline justify-between">
              <label htmlFor="cadastro" className="text-base font-bold text-navy">
                Cadastro
              </label>
              <span className="text-sm text-muted-foreground">Matrícula / E-mail</span>
            </div>
            <div className="mt-2 flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5">
              <UserRound className="h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                id="cadastro"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="Ex: 2410849 ou aluno@puc-rio.br"
                className="min-w-0 flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
              />
            </div>
          </div>

          <div>
            <label htmlFor="senha" className="text-base font-bold text-navy">
              Senha
            </label>
            <div className="mt-2 flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5">
              <Lock className="h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                id="senha"
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="min-w-0 flex-1 bg-transparent text-base outline-none"
              />
              <button type="button" onClick={() => setShow((s) => !s)} aria-label="Mostrar senha">
                {show ? (
                  <Eye className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <EyeOff className="h-5 w-5 text-muted-foreground" />
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-navy px-4 py-4 text-lg font-bold text-primary-foreground shadow-lg transition-colors hover:bg-navy-soft"
          >
            Acessar Mapa <ArrowRight className="h-5 w-5 text-teal" />
          </button>
        </form>

        <div className="mt-7 border-t border-border pt-6">
          <button
            type="button"
            onClick={() => toast.info("Enviamos as instruções de recuperação para o seu e-mail institucional.")}
            className="flex w-full items-center justify-between rounded-2xl px-3 py-3 text-left text-base text-navy hover:bg-muted"
          >
            <span className="flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-muted-foreground" />
              Esqueceu sua senha?
            </span>
            <ExternalLink className="h-5 w-5 text-navy" />
          </button>
          <Link
            to="/cadastro"
            className="mt-2 flex items-center justify-between rounded-2xl border border-teal-soft bg-teal-soft px-4 py-3.5 text-base font-bold text-teal-dark"
          >
            <span className="flex items-center gap-3">
              <UserPlus className="h-5 w-5" />
              Não tem cadastro?
            </span>
            <ExternalLink className="h-5 w-5" />
          </Link>
        </div>
      </div>

      <footer className="px-6 pb-6 pt-10 text-center text-sm text-muted-foreground">
        Campus Wayfinding PUC-Rio • Prédios, Laboratórios e Salas
      </footer>
    </AppFrame>
  );
}
