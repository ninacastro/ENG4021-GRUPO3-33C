import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Camera, Check, ChevronRight, GraduationCap, IdCard, KeyRound, Mail, UserRound } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { ScreenHeader, AppFrame } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { COURSES, initialsOf } from "@/lib/mapuc-data";

export const Route = createFileRoute("/perfil/dados")({
  head: () => ({
    meta: [
      { title: "Dados do perfil — MaPUC PUC-Rio" },
      { name: "description", content: "Altere nome, curso, e-mail e senha da sua conta acadêmica no MaPUC." },
      { property: "og:title", content: "Dados do perfil — MaPUC" },
      { property: "og:description", content: "Atualize as informações da sua conta acadêmica." },
    ],
  }),
  component: DadosPage,
});

const inputRow =
  "flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5 text-base focus-within:border-teal";

function DadosPage() {
  const { student, updateStudent } = useApp();
  const navigate = useNavigate();
  const [name, setName] = useState(student.name);
  const [course, setCourse] = useState(student.course);
  const [email, setEmail] = useState(student.email);

  return (
    <AppFrame>
      <ScreenHeader title="Dados do perfil" back="/perfil" />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          updateStudent({ name, course, email });
          toast.success("Dados atualizados com sucesso.");
          navigate({ to: "/perfil" });
        }}
        className="flex flex-1 flex-col gap-5 px-5 py-6"
      >
        <div className="flex flex-col items-center">
          <button
            type="button"
            onClick={() => toast("Alteração de foto disponível em breve.")}
            className="relative grid h-24 w-24 place-items-center rounded-full bg-navy text-2xl font-extrabold text-primary-foreground"
            aria-label="Alterar foto do perfil"
          >
            {initialsOf(name)}
            <span className="absolute bottom-0 right-0 grid h-8 w-8 place-items-center rounded-full border-2 border-card bg-teal text-primary-foreground">
              <Camera className="h-4 w-4" />
            </span>
          </button>
          <p className="mt-2 text-sm font-semibold text-brand-blue">Alterar foto do perfil</p>
        </div>

        <label className="block">
          <span className="text-sm font-semibold text-navy">Nome</span>
          <div className={`mt-2 ${inputRow}`}>
            <UserRound className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </label>

        <div>
          <div className="flex items-baseline justify-between">
            <span className="text-sm font-semibold text-navy">Matrícula</span>
            <span className="text-xs text-muted-foreground">Somente leitura</span>
          </div>
          <div className="mt-2 flex items-center gap-3 rounded-2xl border border-border bg-muted px-4 py-3.5 text-base text-muted-foreground">
            <IdCard className="h-5 w-5 shrink-0" />
            {student.registration}
          </div>
        </div>

        <label className="block">
          <span className="text-sm font-semibold text-navy">Curso</span>
          <div className={`mt-2 ${inputRow}`}>
            <GraduationCap className="h-5 w-5 shrink-0 text-muted-foreground" />
            <select
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              className="min-w-0 flex-1 bg-transparent outline-none"
            >
              {COURSES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </label>

        <label className="block">
          <span className="text-sm font-semibold text-navy">E-mail</span>
          <div className={`mt-2 ${inputRow}`}>
            <Mail className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </label>

        <div>
          <span className="text-sm font-semibold text-navy">Senha</span>
          <Link
            to="/perfil/senha"
            className="mt-2 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-2xl border border-brand-blue-soft bg-brand-blue-soft/50 px-4 py-4"
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-card text-brand-blue">
              <KeyRound className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block text-base font-bold text-navy">Alterar senha</span>
              <span className="block text-sm text-muted-foreground">{student.passwordUpdated}</span>
            </span>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </Link>
        </div>

        <button
          type="submit"
          className="mt-auto flex items-center justify-center gap-2 rounded-2xl bg-teal py-4 text-lg font-bold text-primary-foreground"
        >
          <Check className="h-5 w-5" /> Salvar alterações
        </button>
      </form>
    </AppFrame>
  );
}
