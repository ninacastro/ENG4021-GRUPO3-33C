import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BookMarked, Clock, MapPin, Navigation, UserRound, Users } from "lucide-react";
import { AppFrame, ScreenHeader } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { CLASSES, WEEKDAY_LABEL } from "@/lib/mapuc-data";

export const Route = createFileRoute("/aula/$id")({
  head: () => ({
    meta: [
      { title: "Detalhes da aula — MaPUC PUC-Rio" },
      { name: "description", content: "Horário, turma, professor e sala da disciplina, com rota a pé até o local." },
      { property: "og:title", content: "Detalhes da aula — MaPUC" },
      { property: "og:description", content: "Veja a sala da sua aula e trace a rota pelo campus." },
    ],
  }),
  component: AulaPage,
});

function Row({ icon: Icon, label, children }: { icon: typeof Clock; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 border-b border-border py-4 last:border-b-0">
      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-brand-blue-soft text-brand-blue">
        <Icon className="h-5 w-5" />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{label}</p>
        <div className="text-base text-navy">{children}</div>
      </div>
    </div>
  );
}

function AulaPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { roomOverrides } = useApp();
  const lesson = CLASSES.find((c) => c.id === id);

  if (!lesson) {
    return (
      <AppFrame>
        <ScreenHeader title="Detalhes da aula" back="/inicio" />
        <div className="flex-1 px-5 py-10 text-center text-muted-foreground">Aula não encontrada.</div>
      </AppFrame>
    );
  }

  const room = roomOverrides[lesson.id] ?? lesson.room;

  return (
    <AppFrame>
      <ScreenHeader
        title="Detalhes da aula"
        back="/inicio"
        right={
          <Link to="/horario" className="rounded-full bg-muted px-3 py-1.5 text-xs font-bold text-navy">
            Horário
          </Link>
        }
      />

      <div className="flex-1 space-y-4 px-5 py-5">
        <section className="card-soft p-5">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <p className="flex min-w-0 items-center gap-2 text-base font-bold text-brand-blue">
              <BookMarked className="h-5 w-5 shrink-0" />
              <span className="truncate">{lesson.code}</span>
            </p>
            <span className="shrink-0 text-sm text-muted-foreground">{lesson.type}</span>
          </div>
          <h1 className="mt-2 text-xl font-extrabold leading-tight text-navy">{lesson.name}</h1>
        </section>

        <section className="card-soft px-5 py-1">
          <Row icon={Clock} label="Horário">
            {WEEKDAY_LABEL[lesson.day]}, {lesson.time}
          </Row>
          <Row icon={Users} label="Turma">
            {lesson.turma}
          </Row>
          <Row icon={UserRound} label="Professor">
            {lesson.professor}
          </Row>
          <Row icon={MapPin} label="Sala">
            <span className="font-bold">{room}</span>{" "}
            {lesson.roomLabel ? <span className="text-muted-foreground">({lesson.roomLabel})</span> : null}
          </Row>
        </section>

        <button
          type="button"
          onClick={() => navigate({ to: "/mapa", search: { sala: room } })}
          className="flex w-full items-center justify-center gap-3 rounded-2xl bg-teal py-4 text-lg font-bold text-primary-foreground"
        >
          <Navigation className="h-5 w-5" /> Ver rota até a sala
        </button>
      </div>
    </AppFrame>
  );
}
