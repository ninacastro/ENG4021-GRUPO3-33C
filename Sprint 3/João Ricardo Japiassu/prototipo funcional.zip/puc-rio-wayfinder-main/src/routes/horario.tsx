import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, CalendarDays, MapPin } from "lucide-react";
import { AppFrame, AppTopBar, BottomNav } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { CLASSES, SLOTS, WEEKDAYS, todayWeekday, type ChipTone } from "@/lib/mapuc-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/horario")({
  head: () => ({
    meta: [
      { title: "Horário de aulas — MaPUC PUC-Rio" },
      { name: "description", content: "Grade semestral 2025.1 com salas, horários e rota a pé até cada aula." },
      { property: "og:title", content: "Horário de aulas — MaPUC" },
      { property: "og:description", content: "Grade semanal interativa da PUC-Rio com rota até a sala." },
    ],
  }),
  component: HorarioPage,
});

const toneClasses: Record<ChipTone, string> = {
  teal: "border-teal bg-teal-soft text-teal-dark",
  blue: "border-brand-blue/40 bg-brand-blue-soft text-brand-blue",
  green: "border-teal-dark/50 bg-teal-soft text-teal-dark",
  indigo: "border-brand-blue/50 bg-brand-blue-soft text-navy",
};

function HorarioPage() {
  const navigate = useNavigate();
  const { roomOverrides } = useApp();
  const today = todayWeekday();
  const todayClass = CLASSES.find((c) => c.day === today);
  const disciplinas = new Set(CLASSES.map((c) => c.code)).size;

  return (
    <AppFrame>
      <AppTopBar subtitle="Grade Semestral • 2025.1" />

      <div className="flex-1 space-y-4 px-4 py-4">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
          <h1 className="flex min-w-0 items-center gap-2 text-xl font-extrabold tracking-tight text-navy">
            <CalendarDays className="h-5 w-5 shrink-0 text-teal-dark" />
            <span className="truncate">HORÁRIO DE AULAS</span>
          </h1>
          <span className="shrink-0 rounded-full border border-teal bg-teal-soft px-3 py-1 text-xs font-bold text-teal-dark">
            {disciplinas} Disciplinas
          </span>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-border bg-card p-2">
          <div className="min-w-[560px]">
            <div className="grid grid-cols-5 border-b border-border">
              {WEEKDAYS.map((d) => (
                <div key={d.key} className="px-2 py-3 text-center">
                  <p className="text-sm font-extrabold text-navy">{d.short}</p>
                  <p className="text-[11px] text-muted-foreground">{d.long}</p>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-5 gap-2 p-2">
              {WEEKDAYS.map((d) => (
                <div key={d.key} className="space-y-2 border-r border-dashed border-border pr-2 last:border-r-0">
                  {SLOTS.map((slot) => {
                    const item = CLASSES.find((c) => c.day === d.key && c.slot === slot);
                    if (!item) {
                      return (
                        <div
                          key={slot}
                          className="grid h-[88px] place-items-center rounded-xl border border-dashed border-border text-[11px] text-muted-foreground"
                        >
                          {d.key === "SEX" && slot !== "11-13" ? "Livre" : slot}
                        </div>
                      );
                    }
                    const room = roomOverrides[item.id] ?? item.room;
                    return (
                      <div
                        key={slot}
                        className={cn(
                          "flex h-[88px] flex-col justify-between rounded-xl border-2 p-2",
                          toneClasses[item.tone],
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => navigate({ to: "/aula/$id", params: { id: item.id } })}
                          className="text-left"
                        >
                          <p className="text-xs font-extrabold text-navy">{item.code}</p>
                          <p className="text-[11px] font-bold">{item.time.replace(/\s/g, "")}</p>
                        </button>
                        <button
                          type="button"
                          onClick={() => navigate({ to: "/mapa", search: { sala: room } })}
                          className="flex items-center gap-1 rounded-lg bg-card/80 px-2 py-1 text-[11px] font-bold text-navy"
                        >
                          <MapPin className="h-3 w-3 text-teal-dark" />
                          {room}
                        </button>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-start gap-3 rounded-2xl border border-teal-soft bg-card p-4">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-teal-soft text-teal-dark">
            <MapPin className="h-6 w-6" />
          </span>
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-sm font-extrabold tracking-wide text-navy">
              CLIQUE NA SALA DESEJADA <span className="h-2 w-2 rounded-full bg-teal-dark" />
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              Redirecionamento automático ao mapa para traçar a melhor rota a pé pelo campus da PUC-Rio.
            </p>
          </div>
        </div>

        {todayClass ? (
          <section className="rounded-2xl bg-navy p-4 text-primary-foreground">
            <p className="text-xs font-bold tracking-wider text-teal">
              AULA HOJE ({WEEKDAYS.find((d) => d.key === today)?.long.toUpperCase()})
            </p>
            <div className="mt-1 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
              <div className="min-w-0">
                <p className="truncate text-lg font-bold">
                  {todayClass.code} • Sala {roomOverrides[todayClass.id] ?? todayClass.room}
                </p>
                <p className="truncate text-xs text-primary-foreground/70">
                  {todayClass.professor} — Início às {todayClass.time.slice(0, 5)}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  navigate({ to: "/mapa", search: { sala: roomOverrides[todayClass.id] ?? todayClass.room } })
                }
                className="flex shrink-0 items-center gap-2 rounded-xl bg-teal-dark px-4 py-2.5 text-sm font-bold"
              >
                Ir Agora <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </section>
        ) : null}
      </div>

      <BottomNav />
    </AppFrame>
  );
}
