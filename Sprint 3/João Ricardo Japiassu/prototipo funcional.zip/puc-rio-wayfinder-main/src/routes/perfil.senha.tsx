import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check, KeyRound, Lock } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppFrame, ScreenHeader } from "@/components/mapuc/shell";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/perfil/senha")({
  head: () => ({
    meta: [
      { title: "Alterar senha — MaPUC PUC-Rio" },
      { name: "description", content: "Crie uma nova senha para a sua conta acadêmica no MaPUC." },
      { property: "og:title", content: "Alterar senha — MaPUC" },
      { property: "og:description", content: "Atualize a senha de acesso ao MaPUC." },
    ],
  }),
  component: SenhaPage,
});

const inputRow =
  "flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5 text-base focus-within:border-teal";

function SenhaPage() {
  const navigate = useNavigate();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");

  const rules = useMemo(
    () => [
      { label: "Mínimo 8 caracteres", ok: next.length >= 8 },
      { label: "Mínimo 2 símbolos", ok: (next.match(/[^A-Za-z0-9]/g) ?? []).length >= 2 },
      { label: "Mínimo 1 número", ok: /\d/.test(next) },
    ],
    [next],
  );

  return (
    <AppFrame>
      <ScreenHeader title="Alterar senha" back="/perfil/dados" />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!current) {
            toast.error("Informe a senha atual.");
            return;
          }
          if (rules.some((r) => !r.ok)) {
            toast.error("A nova senha não atende aos critérios.");
            return;
          }
          if (next !== confirm) {
            toast.error("As senhas não conferem.");
            return;
          }
          toast.success("Senha alterada com sucesso.");
          navigate({ to: "/perfil/dados" });
        }}
        className="flex flex-1 flex-col gap-5 px-5 py-6"
      >
        <label className="block">
          <span className="text-sm font-semibold text-navy">Senha atual</span>
          <div className={`mt-2 ${inputRow}`}>
            <Lock className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type="password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              placeholder="Digite sua senha atual"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </label>

        <label className="block">
          <span className="text-sm font-semibold text-navy">Nova senha</span>
          <div className={`mt-2 ${inputRow}`}>
            <KeyRound className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type="password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              placeholder="Crie sua nova senha"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {rules.map((r) => (
              <span
                key={r.label}
                className={cn(
                  "flex items-center gap-2 rounded-lg border bg-card px-3 py-1.5 text-xs font-medium",
                  r.ok ? "border-teal text-teal-dark" : "border-border text-muted-foreground",
                )}
              >
                <span className={cn("h-2 w-2 rounded-full", r.ok ? "bg-teal-dark" : "bg-brand-blue")} />
                {r.label}
              </span>
            ))}
          </div>
        </label>

        <label className="block">
          <span className="text-sm font-semibold text-navy">Confirmar nova senha</span>
          <div className={`mt-2 ${inputRow}`}>
            <Lock className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Digite a senha novamente"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </label>

        <button
          type="submit"
          className="mt-auto flex items-center justify-center gap-2 rounded-2xl bg-teal py-4 text-lg font-bold text-primary-foreground"
        >
          <Check className="h-5 w-5" /> Salvar nova senha
        </button>
      </form>
    </AppFrame>
  );
}
