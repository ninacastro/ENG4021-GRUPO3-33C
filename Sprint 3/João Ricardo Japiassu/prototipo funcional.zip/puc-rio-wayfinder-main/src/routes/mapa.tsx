import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Building2, Footprints, LocateFixed, Navigation, X } from "lucide-react";
import { useMemo, useState } from "react";
import { CampusMap, routePointsTo } from "@/components/mapuc/CampusMap";
import { AppFrame, AppTopBar, BottomNav } from "@/components/mapuc/shell";
import { BUILDINGS, buildingById, classByRoom, findRoom } from "@/lib/mapuc-data";

type MapSearch = { sala?: string; predio?: string };

export const Route = createFileRoute("/mapa")({
  validateSearch: (search: Record<string, unknown>): MapSearch => ({
    ...(typeof search["sala"] === "string" ? { sala: search["sala"] } : {}),
    ...(typeof search["predio"] === "string" ? { predio: search["predio"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Mapa do campus — MaPUC PUC-Rio" },
      { name: "description", content: "Mapa interativo do campus da Gávea com rota a pé até salas, blocos e serviços." },
      { property: "og:title", content: "Mapa do campus — MaPUC" },
      { property: "og:description", content: "Rotas a pé entre os prédios da PUC-Rio, com andar e passo a passo." },
    ],
  }),
  component: MapaPage,
});

function MapaPage() {
  const { sala, predio } = Route.useSearch();
  const navigate = useNavigate();

  const roomHit = sala ? findRoom(sala) : undefined;
  const initialId = roomHit?.building.id ?? predio;
  const [manualId, setManualId] = useState<string | undefined>(undefined);

  const selectedId = manualId ?? initialId;
  const building = selectedId ? buildingById(selectedId) : undefined;
  const room = manualId && manualId !== initialId ? undefined : roomHit?.room ?? (sala || undefined);

  const route = useMemo(() => (building ? routePointsTo(building) : undefined), [building]);
  const lesson = room ? classByRoom(room) : undefined;

  const steps = building
    ? [
        "Saia dos Pilotis e siga pela via central do campus.",
        `Caminhe cerca de ${building.walkMinutes} min em direção ao prédio ${building.name}.`,
        `Entre no prédio ${building.name} pela entrada principal (bloco ${building.letter}).`,
        ...(room && lesson
          ? [
              `Suba até o ${lesson.floor}º andar pelo elevador ou escada central.`,
              `A sala ${room} fica no corredor à direita, ao fim do hall.`,
            ]
          : [`Procure a recepção do bloco ${building.letter} para orientações internas.`]),
      ]
    : [];

  return (
    <AppFrame>
      <AppTopBar subtitle="Campus Gávea • Mapa interativo" />

      <div className="flex-1 overflow-y-auto">
        <div className="relative">
          <div className="h-[420px] w-full">
            <CampusMap
              selectedId={selectedId ?? ""}
              onSelect={(id) => {
                setManualId(id);
                navigate({ to: "/mapa", search: { predio: id }, replace: true });
              }}
              {...(route ? { route } : {})}
            />
          </div>
          <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-full bg-card/90 px-3 py-1.5 text-xs font-semibold text-navy shadow-sm">
            <LocateFixed className="h-4 w-4 text-teal-dark" /> Você está nos Pilotis
          </div>
        </div>

        <div className="space-y-3 px-4 py-4">
          {building ? (
            <section className="card-soft p-4">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Destino</p>
                  <h2 className="truncate text-lg font-extrabold text-navy">
                    {room ? `Sala ${room}` : building.name}
                  </h2>
                  <p className="truncate text-sm text-muted-foreground">
                    {room ? `${building.name} • ${building.kind}` : building.kind}
                  </p>
                </div>
                <button
                  type="button"
                  aria-label="Limpar rota"
                  onClick={() => {
                    setManualId(undefined);
                    navigate({ to: "/mapa", search: {}, replace: true });
                  }}
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-navy"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold">
                <span className="flex items-center gap-1.5 rounded-full bg-teal-soft px-3 py-1.5 text-teal-dark">
                  <Footprints className="h-4 w-4" /> {building.walkMinutes} min a pé
                </span>
                {lesson ? (
                  <span className="flex items-center gap-1.5 rounded-full bg-brand-blue-soft px-3 py-1.5 text-brand-blue">
                    <Building2 className="h-4 w-4" /> {lesson.floor}º andar • {lesson.code}
                  </span>
                ) : null}
              </div>

              <ol className="mt-4 space-y-3">
                {steps.map((s, i) => (
                  <li key={s} className="flex gap-3">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-navy text-[11px] font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <span className="text-sm text-navy">{s}</span>
                  </li>
                ))}
              </ol>

              {lesson ? (
                <button
                  type="button"
                  onClick={() => navigate({ to: "/aula/$id", params: { id: lesson.id } })}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-teal py-3.5 text-base font-bold text-primary-foreground"
                >
                  <Navigation className="h-5 w-5" /> Ver detalhes da aula
                </button>
              ) : null}
            </section>
          ) : (
            <section className="card-soft p-4">
              <h2 className="text-base font-bold text-navy">Toque em um prédio para traçar a rota</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Você também pode chegar aqui pela busca da tela inicial ou clicando na sala no seu horário.
              </p>
            </section>
          )}

          <section className="card-soft p-4">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Prédios do campus</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {BUILDINGS.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => {
                    setManualId(b.id);
                    navigate({ to: "/mapa", search: { predio: b.id }, replace: true });
                  }}
                  className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold text-navy hover:border-teal"
                >
                  {b.name}
                </button>
              ))}
            </div>
          </section>
        </div>
      </div>

      <BottomNav />
    </AppFrame>
  );
}
