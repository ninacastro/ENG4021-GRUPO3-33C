import { createFileRoute } from "@tanstack/react-router";
import { AppFrame, ScreenHeader } from "@/components/mapuc/shell";

export const Route = createFileRoute("/perfil/ajuda")({
  head: () => ({
    meta: [
      { title: "Ajuda e suporte — MaPUC PUC-Rio" },
      { name: "description", content: "Dúvidas frequentes sobre rotas, salas e avisos no campus da PUC-Rio." },
      { property: "og:title", content: "Ajuda e suporte — MaPUC" },
      { property: "og:description", content: "Perguntas frequentes e contato do suporte do campus." },
    ],
  }),
  component: AjudaPage,
});

const faq = [
  {
    q: "Como traço uma rota até a sala?",
    a: "Toque na sala no seu horário ou busque o código dela na tela inicial. O mapa abre já com o caminho a pé e o andar.",
  },
  {
    q: "A sala da minha aula mudou. E agora?",
    a: "Abra os Avisos e toque em “Atualizar rota automaticamente”. A nova sala passa a valer na grade e no mapa.",
  },
  {
    q: "Posso usar no computador?",
    a: "Sim. Use o seletor no canto superior direito para alternar entre a visualização de celular e a de computador.",
  },
  {
    q: "Preciso de mais ajuda",
    a: "Fale com o suporte do campus pelo e-mail suporte.mapuc@puc-rio.br ou na central de atendimento do RDC.",
  },
];

function AjudaPage() {
  return (
    <AppFrame>
      <ScreenHeader title="Ajuda e suporte" back="/perfil" />
      <div className="flex-1 space-y-3 px-5 py-6">
        {faq.map((f) => (
          <section key={f.q} className="card-soft p-4">
            <h2 className="text-base font-bold text-navy">{f.q}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{f.a}</p>
          </section>
        ))}
      </div>
    </AppFrame>
  );
}
