import { createFileRoute } from "@tanstack/react-router";
import { AppFrame, ScreenHeader } from "@/components/mapuc/shell";

export const Route = createFileRoute("/perfil/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de privacidade — MaPUC PUC-Rio" },
      { name: "description", content: "Como o MaPUC trata seus dados acadêmicos e sua localização no campus." },
      { property: "og:title", content: "Política de privacidade — MaPUC" },
      { property: "og:description", content: "Proteção de dados e uso da localização no campus da PUC-Rio." },
    ],
  }),
  component: PrivacidadePage,
});

const blocks = [
  {
    title: "Dados que usamos",
    text: "Nome, matrícula, curso e e-mail institucional servem apenas para identificar você e montar a sua grade de aulas.",
  },
  {
    title: "Localização no campus",
    text: "A localização é usada somente enquanto o mapa está aberto, para traçar a rota a pé até a sala escolhida. Nada é gravado depois.",
  },
  {
    title: "Compartilhamento",
    text: "Não compartilhamos seus dados com terceiros. Avisos de mudança de sala vêm dos professores e departamentos da PUC-Rio.",
  },
  {
    title: "Seus direitos",
    text: "Você pode atualizar ou solicitar a exclusão dos seus dados a qualquer momento pela tela de perfil ou com o suporte do campus.",
  },
];

function PrivacidadePage() {
  return (
    <AppFrame>
      <ScreenHeader title="Política de privacidade" back="/perfil" />
      <div className="flex-1 space-y-3 px-5 py-6">
        {blocks.map((b) => (
          <section key={b.title} className="card-soft p-4">
            <h2 className="text-base font-bold text-navy">{b.title}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{b.text}</p>
          </section>
        ))}
      </div>
    </AppFrame>
  );
}
