import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Bell, BookOpen, Building2, CircleHelp, MapPin, Search, ShoppingCart, Star } from "lucide-react";
import { useState } from "react";
import { MapucMark } from "@/components/mapuc/Logo";
import { AppFrame, BottomNav, MenuDrawer } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { CLASSES, initialsOf, searchCampus, todayWeekday, WEEKDAY_LABEL } from "@/lib/mapuc-data";

export const Route = createFileRoute("/inicio")({
  head: () => ({
    meta: [
      { title: "Início — MaPUC PUC-Rio" },
      { name: "description", content: "Busque salas, blocos e serviços da PUC-Rio e veja sua próxima aula de hoje." },
      { property: "og:title", content: "Início — MaPUC" },
      { property: "og:description", content: "Se encontre pelos blocos, salas e pilotis da PUC-Rio." },
    ],
  }),
  component: InicioPage,
});

function InicioPage() {
  const navigate = useNavigate();
  const { student, roomOverrides, unreadCount } = useApp();
  const [query, setQuery] = useState("");
  const results = searchCampus(query);

  const today = todayWeekday();
  const nextClass = CLASSES.find((c) => c.day === today) ?? CLASSES[0]!;
  const room = roomOverrides[nextClass.id] ?? nextClass.room;

  return (
    <AppFrame>
      <div className="flex flex-1">
        <aside className="flex w-16 shrink-0 flex-col items-center gap-6 border-r border-border bg-card py-4">
          <MenuDrawer />
          <div className="h-px w-8 bg-border" />
          <Link to="/mapa" aria-label="Prédios" className="text-navy-muted hover:text-navy">
            <Building2 className="h-5 w-5" />
          </Link>
          <Link to="/horario" aria-label="Horário" className="text-navy-muted hover:text-navy">
            <Star className="h-5 w-5" />
          </Link>
          <Link to="/avisos" aria-label="Avisos" className="relative text-navy-muted hover:text-navy">
            <CircleHelp className="h-5 w-5" />
            {unreadCount > 0 ? <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-danger" /> : null}
          </Link>
          <span className="mt-auto text-[10px] font-semibold text-muted-foreground">v2.4.1</span>
        </aside>

        <div className="min-w-0 flex-1 px-5 pb-6 pt-4">
          <div className="flex justify-end">
            <Link
              to="/perfil"
              className="flex items-center gap-2 rounded-full border border-border bg-card py-1 pl-4 pr-1 text-sm font-medium text-navy"
            >
              {student.name.split(" ")[0]}
              <span className="relative grid h-8 w-8 place-items-center rounded-full bg-muted text-xs font-bold">
                {initialsOf(student.name)}
                <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-card bg-teal-dark" />
              </span>
            </Link>
          </div>

          <div className="mt-2 flex flex-col items-center">
            <div className="grid h-24 w-32 place-items-center rounded-2xl bg-card">
              <MapucMark className="h-12 w-12" />
              <p className="text-sm font-extrabold">
                <span className="text-teal-dark">Ma</span>
                <span className="text-navy">PUC</span>
              </p>
            </div>
            <div className="mt-3 h-1 w-10 rounded-full bg-border" />
            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-navy">TELA DE INÍCIO</h1>
            <p className="mt-1 text-center text-sm text-muted-foreground">
              Se encontre pelos blocos, salas e pilotis da PUC-Rio.
            </p>
          </div>

          <div className="relative mt-5">
            <div className="flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3">
              <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar sala, bloco ou serviço (ex: L318)"
                className="min-w-0 flex-1 bg-transparent text-sm outline-none"
              />
              <span className="shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground">
                PUC
              </span>
            </div>
            {results.length > 0 ? (
              <ul className="absolute z-10 mt-2 w-full overflow-hidden rounded-2xl border border-border bg-card shadow-lg">
                {results.map((r) => (
                  <li key={`${r.buildingId}-${r.title}`}>
                    <button
                      type="button"
                      onClick={() =>
                        navigate({
                          to: "/mapa",
                          search: r.room ? { sala: r.room } : { predio: r.buildingId },
                        })
                      }
                      className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-muted"
                    >
                      <MapPin className="h-4 w-4 shrink-0 text-teal-dark" />
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-semibold text-navy">{r.title}</span>
                        <span className="block truncate text-xs text-muted-foreground">{r.subtitle}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          <section className="mt-4 rounded-2xl bg-navy p-4 text-primary-foreground">
            <p className="flex items-center justify-between text-xs font-bold tracking-wider text-teal">
              <span className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-teal" /> PRÓXIMA AULA HOJE
              </span>
              <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] text-primary-foreground">
                {nextClass.time.slice(0, 5)}
              </span>
            </p>
            <div className="mt-2 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
              <div className="min-w-0">
                <p className="truncate text-lg font-bold">
                  {nextClass.code} • Sala {room}
                </p>
                <p className="truncate text-xs text-primary-foreground/70">
                  {WEEKDAY_LABEL[nextClass.day]} — {nextClass.professor}
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate({ to: "/mapa", search: { sala: room } })}
                className="flex shrink-0 items-center gap-2 rounded-xl bg-teal-dark px-4 py-2.5 text-sm font-bold text-primary-foreground"
              >
                Rotear <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </section>

          <div className="mt-3 grid grid-cols-2 gap-3">
            <Link
              to="/mapa"
              search={{ predio: "biblioteca" }}
              className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-teal-soft text-teal-dark">
                <BookOpen className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-bold text-navy">Biblioteca</span>
                <span className="block truncate text-xs text-muted-foreground">Acervo & Estudo</span>
              </span>
            </Link>
            <Link
              to="/mapa"
              search={{ predio: "vila" }}
              className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-blue-soft text-brand-blue">
                <ShoppingCart className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-bold text-navy">Alimentação</span>
                <span className="block truncate text-xs text-muted-foreground">Vila dos Diretórios</span>
              </span>
            </Link>
          </div>

          <Link
            to="/avisos"
            className="mt-3 flex items-center gap-3 rounded-2xl border border-border bg-card p-3 text-navy"
          >
            <span className="relative grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-danger-soft text-danger">
              <Bell className="h-5 w-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-bold">Avisos e recados</span>
              <span className="block truncate text-xs text-muted-foreground">
                {unreadCount > 0 ? `${unreadCount} novos alertas de sala e aulas` : "Tudo em dia por aqui"}
              </span>
            </span>
            <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
          </Link>
        </div>
      </div>
      <BottomNav />
    </AppFrame>
  );
}
