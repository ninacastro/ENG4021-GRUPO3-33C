import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  CircleHelp,
  Eye,
  EyeOff,
  Keyboard,
  Lock,
  Mail,
  Map as MapIcon,
  MapPin,
  QrCode,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { OtpDialog } from "@/components/mapuc/OtpDialog";
import { AppFrame } from "@/components/mapuc/shell";
import { useApp } from "@/lib/app-state";
import { COURSES } from "@/lib/mapuc-data";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/cadastro")({
  head: () => ({
    meta: [
      { title: "Criar cadastro — MaPUC PUC-Rio" },
      { name: "description", content: "Crie sua conta no MaPUC e navegue pelas salas, blocos e serviços da PUC-Rio." },
      { property: "og:title", content: "Criar cadastro no MaPUC" },
      { property: "og:description", content: "Junte-se ao app de wayfinding do campus da PUC-Rio." },
    ],
  }),
  component: CadastroPage,
});

function Field({
  label,
  required,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-bold uppercase tracking-wider text-navy">
          {label} {required ? <span className="text-danger">*</span> : null}
        </span>
        {hint ? <span className="text-xs text-muted-foreground">{hint}</span> : null}
      </div>
      <div className="mt-2">{children}</div>
    </div>
  );
}

const inputRow =
  "flex items-center gap-3 rounded-2xl border border-border bg-card px-4 py-3.5 text-base focus-within:border-brand-blue";

function CadastroPage() {
  const navigate = useNavigate();
  const { signIn, updateStudent } = useApp();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [cep, setCep] = useState("");
  const [address, setAddress] = useState("");
  const [cepLoading, setCepLoading] = useState(false);
  const [course, setCourse] = useState("");
  const [registration, setRegistration] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [news, setNews] = useState(false);
  const [terms, setTerms] = useState(false);
  const [otpOpen, setOtpOpen] = useState(false);

  const rules = useMemo(
    () => [
      { label: "Mínimo 8 caracteres", ok: password.length >= 8 },
      { label: "Mínimo 2 símbolos", ok: (password.match(/[^A-Za-z0-9]/g) ?? []).length >= 2 },
      { label: "Mínimo 1 número", ok: /\d/.test(password) },
    ],
    [password],
  );

  async function lookupCep(value: string) {
    const digits = value.replace(/\D/g, "");
    if (digits.length !== 8) return;
    setCepLoading(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${digits}/json/`);
      const data = (await res.json()) as { erro?: boolean; logradouro?: string; bairro?: string; localidade?: string; uf?: string };
      if (data.erro) {
        setAddress("");
        toast.error("CEP não encontrado. Você pode seguir sem ele.");
        return;
      }
      setAddress([data.logradouro, data.bairro, `${data.localidade} - ${data.uf}`].filter(Boolean).join(", "));
    } catch {
      toast.error("Não foi possível buscar o endereço agora.");
    } finally {
      setCepLoading(false);
    }
  }

  function next(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !registration.trim()) {
      toast.error("Preencha nome, e-mail e matrícula.");
      return;
    }
    if (rules.some((r) => !r.ok)) {
      toast.error("A senha ainda não atende aos critérios de segurança.");
      return;
    }
    if (password !== confirm) {
      toast.error("As senhas não conferem.");
      return;
    }
    if (!terms) {
      toast.error("É preciso concordar com a Política de Uso e Privacidade.");
      return;
    }
    setOtpOpen(true);
  }

  return (
    <AppFrame requireAuth={false}>
      <header className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-card px-4 py-4">
        <Link to="/" aria-label="Voltar" className="grid h-9 w-9 place-items-center rounded-full text-navy hover:bg-muted">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <span className="mx-auto flex items-center gap-2 rounded-full bg-brand-blue-soft px-4 py-2 text-sm font-bold tracking-wide text-brand-blue">
          <MapIcon className="h-4 w-4" /> PUC MAPA GUIA
        </span>
        <CircleHelp className="h-5 w-5 text-muted-foreground" />
      </header>

      <form onSubmit={next} className="flex-1 space-y-5 px-5 py-6">
        <span className="inline-block rounded-lg bg-brand-blue-soft px-3 py-1 text-xs font-bold tracking-wider text-brand-blue">
          CAMPUS WAYFINDING
        </span>
        <div>
          <h1 className="text-3xl font-extrabold text-navy">Nunca se cadastrou?</h1>
          <p className="text-xl font-bold text-brand-blue">Junte-se ao nosso app!</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Navegue facilmente pelas salas, auditórios, blocos e serviços da universidade direto no mapa interativo.
          </p>
        </div>

        <Field label="Nome completo" required>
          <div className={inputRow}>
            <UserRound className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Mariana Silva e Souza"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </Field>

        <Field label="Email" required hint="Preferência institucional">
          <div className={inputRow}>
            <Mail className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="aluno@puc.br ou seu email"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </Field>

        <Field label="CEP" {...(cepLoading ? { hint: "Buscando..." } : {})}>
          <div className={inputRow}>
            <MapPin className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              inputMode="numeric"
              value={cep}
              onChange={(e) => setCep(e.target.value)}
              onBlur={(e) => lookupCep(e.target.value)}
              placeholder="00000-000"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
          {address ? <p className="mt-2 text-xs text-teal-dark">{address}</p> : null}
        </Field>

        <Field label="Curso">
          <div className={inputRow}>
            <select
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              className="min-w-0 flex-1 bg-transparent outline-none"
            >
              <option value="">Selecione seu curso...</option>
              {COURSES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </Field>

        <Field label="Matrícula" required>
          <div className={inputRow}>
            <QrCode className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              inputMode="numeric"
              value={registration}
              onChange={(e) => setRegistration(e.target.value)}
              placeholder="Ex: 2024108849"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
          </div>
        </Field>

        <Field label="Senha" required>
          <div className={inputRow}>
            <Lock className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type={showPass ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Crie sua senha segura"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
            <button type="button" onClick={() => setShowPass((s) => !s)} aria-label="Mostrar senha">
              {showPass ? <EyeOff className="h-5 w-5 text-muted-foreground" /> : <Eye className="h-5 w-5 text-muted-foreground" />}
            </button>
          </div>
          <div className="mt-3 rounded-2xl border border-brand-blue-soft bg-brand-blue-soft/60 p-3">
            <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-brand-blue">
              <ShieldCheck className="h-4 w-4" /> Critérios de segurança:
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {rules.map((r) => (
                <span
                  key={r.label}
                  className={cn(
                    "flex items-center gap-2 rounded-lg border bg-card px-3 py-1.5 text-xs font-medium",
                    r.ok ? "border-teal text-teal-dark" : "border-border text-muted-foreground",
                  )}
                >
                  <span className={cn("h-2 w-2 rounded-full", r.ok ? "bg-teal-dark" : "bg-brand-blue")} />
                  {r.label}
                </span>
              ))}
            </div>
          </div>
        </Field>

        <Field label="Confirmar senha" required>
          <div className={inputRow}>
            <Keyboard className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              type={showConfirm ? "text" : "password"}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Digite a senha novamente"
              className="min-w-0 flex-1 bg-transparent outline-none"
            />
            <button type="button" onClick={() => setShowConfirm((s) => !s)} aria-label="Mostrar confirmação">
              {showConfirm ? <EyeOff className="h-5 w-5 text-muted-foreground" /> : <Eye className="h-5 w-5 text-muted-foreground" />}
            </button>
          </div>
        </Field>

        <label className="flex items-start gap-3 text-sm text-navy">
          <input type="checkbox" checked={news} onChange={(e) => setNews(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[var(--brand-blue)]" />
          Receber notícias, avisos, atualizações
        </label>
        <label className="flex items-start gap-3 text-sm text-navy">
          <input type="checkbox" checked={terms} onChange={(e) => setTerms(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[var(--brand-blue)]" />
          <span>
            Concordar com nossa{" "}
            <span className="font-semibold text-brand-blue underline">Política de Uso e Privacidade</span>
          </span>
        </label>

        <div className="flex gap-3 pt-2">
          <Link
            to="/"
            className="flex-1 rounded-2xl border border-border bg-card py-3.5 text-center text-sm font-bold tracking-wider text-navy"
          >
            SAIR
          </Link>
          <button
            type="submit"
            className="flex flex-[1.6] items-center justify-center gap-2 rounded-2xl bg-brand-blue py-3.5 text-sm font-bold tracking-wider text-primary-foreground"
          >
            PRÓXIMO <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <p className="border-t border-border pt-4 text-center text-xs text-muted-foreground">
          Campus Wayfinding PUC • Prédios, Laboratórios e Salas
        </p>
      </form>

      <OtpDialog
        open={otpOpen}
        email={email || "aluno@puc.br"}
        onOpenChange={setOtpOpen}
        onChangeEmail={() => setOtpOpen(false)}
        onConfirmed={() => {
          updateStudent({
            name: name || undefined,
            email: email || undefined,
            registration: registration || undefined,
            course: course || undefined,
          } as never);
          signIn(email);
          toast.success("Cadastro confirmado. Bem-vindo ao MaPUC!");
          navigate({ to: "/inicio" });
        }}
      />
    </AppFrame>
  );
}
