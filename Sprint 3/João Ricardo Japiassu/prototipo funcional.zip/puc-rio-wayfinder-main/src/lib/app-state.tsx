import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_STUDENT, NOTICES, type Notice } from "./mapuc-data";

export type Student = typeof DEFAULT_STUDENT;
export type DeviceMode = "mobile" | "desktop";

type Overrides = Record<string, string>; // classId -> nova sala

type AppState = {
  hydrated: boolean;
  signedIn: boolean;
  signIn: (identifier: string) => void;
  signOut: () => void;
  student: Student;
  updateStudent: (patch: Partial<Student>) => void;
  device: DeviceMode;
  setDevice: (d: DeviceMode) => void;
  notices: Notice[];
  readIds: string[];
  markRead: (id: string) => void;
  markAllRead: () => void;
  unreadCount: number;
  roomOverrides: Overrides;
  applyRoomChange: (classId: string, room: string) => void;
};

const Ctx = createContext<AppState | null>(null);

const KEY = "mapuc.state.v1";

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [student, setStudent] = useState<Student>(DEFAULT_STUDENT);
  const [device, setDeviceState] = useState<DeviceMode>("mobile");
  const [readIds, setReadIds] = useState<string[]>([]);
  const [roomOverrides, setRoomOverrides] = useState<Overrides>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.signedIn) setSignedIn(true);
        if (parsed.student) setStudent({ ...DEFAULT_STUDENT, ...parsed.student });
        if (parsed.device) setDeviceState(parsed.device);
        if (Array.isArray(parsed.readIds)) setReadIds(parsed.readIds);
        if (parsed.roomOverrides) setRoomOverrides(parsed.roomOverrides);
      }
    } catch {
      /* ignora armazenamento indisponível */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(KEY, JSON.stringify({ signedIn, student, device, readIds, roomOverrides }));
    } catch {
      /* ignora armazenamento indisponível */
    }
  }, [hydrated, signedIn, student, device, readIds, roomOverrides]);

  const value = useMemo<AppState>(
    () => ({
      hydrated,
      signedIn,
      signIn: () => setSignedIn(true),
      signOut: () => setSignedIn(false),
      student,
      updateStudent: (patch) => setStudent((s) => ({ ...s, ...patch })),
      device,
      setDevice: setDeviceState,
      notices: NOTICES,
      readIds,
      markRead: (id) => setReadIds((prev) => (prev.includes(id) ? prev : [...prev, id])),
      markAllRead: () => setReadIds(NOTICES.map((n) => n.id)),
      unreadCount: NOTICES.filter((n) => !readIds.includes(n.id)).length,
      roomOverrides,
      applyRoomChange: (classId, room) => setRoomOverrides((prev) => ({ ...prev, [classId]: room })),
    }),
    [hydrated, signedIn, student, device, readIds, roomOverrides],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp precisa estar dentro de AppStateProvider");
  return ctx;
}

export function useRoomOf() {
  const { roomOverrides } = useApp();
  return useCallback(
    (classId: string, fallback: string) => roomOverrides[classId] ?? fallback,
    [roomOverrides],
  );
}
