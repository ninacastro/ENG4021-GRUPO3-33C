export type Weekday = "SEG" | "TER" | "QUA" | "QUI" | "SEX";
export type Slot = "07-09" | "09-11" | "11-13" | "14-16" | "16-18";

export const WEEKDAYS: { key: Weekday; short: string; long: string }[] = [
  { key: "SEG", short: "SEG", long: "2ª feira" },
  { key: "TER", short: "TER", long: "3ª feira" },
  { key: "QUA", short: "QUA", long: "4ª feira" },
  { key: "QUI", short: "QUI", long: "5ª feira" },
  { key: "SEX", short: "SEX", long: "6ª feira" },
];

export const SLOTS: Slot[] = ["07-09", "09-11", "11-13", "14-16", "16-18"];

export const WEEKDAY_LABEL: Record<Weekday, string> = {
  SEG: "Segunda-feira",
  TER: "Terça-feira",
  QUA: "Quarta-feira",
  QUI: "Quinta-feira",
  SEX: "Sexta-feira",
};

export type ChipTone = "teal" | "blue" | "green" | "indigo";

export type CampusClass = {
  id: string;
  code: string;
  name: string;
  type: "Obrigatória" | "Eletiva";
  day: Weekday;
  slot: Slot;
  time: string;
  turma: string;
  professor: string;
  room: string;
  roomLabel?: string;
  buildingId: string;
  floor: number;
  tone: ChipTone;
};

export const CLASSES: CampusClass[] = [
  {
    id: "inf1005-seg",
    code: "INF1005",
    name: "PROGRAMAÇÃO I",
    type: "Obrigatória",
    day: "SEG",
    slot: "07-09",
    time: "07:00 - 09:00",
    turma: "3WA",
    professor: "Ana Paula Rocha",
    room: "L318",
    buildingId: "leme",
    floor: 3,
    tone: "teal",
  },
  {
    id: "mat1161-ter",
    code: "MAT1161",
    name: "CÁLCULO A UMA VARIÁVEL",
    type: "Obrigatória",
    day: "TER",
    slot: "09-11",
    time: "09:00 - 11:00",
    turma: "12B",
    professor: "Roberto Muniz",
    room: "K102",
    buildingId: "kennedy",
    floor: 1,
    tone: "blue",
  },
  {
    id: "eng1000-qua",
    code: "ENG1000",
    name: "INTRODUÇÃO À ENGENHARIA",
    type: "Obrigatória",
    day: "QUA",
    slot: "09-11",
    time: "09:00 - 11:00",
    turma: "07A",
    professor: "Cláudia Menezes",
    room: "F402",
    buildingId: "frings",
    floor: 4,
    tone: "green",
  },
  {
    id: "fis1025-qua",
    code: "FIS1025",
    name: "FÍSICA EXPERIMENTAL",
    type: "Obrigatória",
    day: "QUA",
    slot: "11-13",
    time: "11:00 - 13:00",
    turma: "21C",
    professor: "Marcelo Tavares",
    room: "L112",
    buildingId: "leme",
    floor: 1,
    tone: "green",
  },
  {
    id: "let1010-qui",
    code: "LET1010",
    name: "PORTUGUÊS INSTRUMENTAL",
    type: "Eletiva",
    day: "QUI",
    slot: "07-09",
    time: "07:00 - 09:00",
    turma: "05D",
    professor: "Beatriz Lins",
    room: "R204",
    buildingId: "rdc",
    floor: 2,
    tone: "indigo",
  },
  {
    id: "mat1161-qui",
    code: "MAT1161",
    name: "CÁLCULO A UMA VARIÁVEL",
    type: "Obrigatória",
    day: "QUI",
    slot: "14-16",
    time: "14:00 - 16:00",
    turma: "12B",
    professor: "Roberto Muniz",
    room: "L206",
    buildingId: "leme",
    floor: 2,
    tone: "blue",
  },
  {
    id: "eng4021-sex",
    code: "ENG4021",
    name: "PROJETO INTEGRADO - SOFTWARE",
    type: "Obrigatória",
    day: "SEX",
    slot: "11-13",
    time: "11:00 - 13:00",
    turma: "33C",
    professor: "Luís Fernando Bicalho",
    room: "LIENG",
    roomLabel: "Laboratório de Informática",
    buildingId: "leme",
    floor: 5,
    tone: "teal",
  },
];

export type Building = {
  id: string;
  name: string;
  letter: string;
  kind: string;
  rooms: string[];
  /** posição no mapa SVG (viewBox 0 0 360 520) */
  x: number;
  y: number;
  w: number;
  h: number;
  /** waypoints do caminho a pé a partir dos Pilotis */
  via: [number, number][];
  walkMinutes: number;
};

export const YOU_ARE_HERE: [number, number] = [176, 300];

export const BUILDINGS: Building[] = [
  {
    id: "pilotis",
    name: "Pilotis",
    letter: "P",
    kind: "Área de convivência",
    rooms: ["Pilotis"],
    x: 128,
    y: 276,
    w: 100,
    h: 48,
    via: [],
    walkMinutes: 0,
  },
  {
    id: "leme",
    name: "Cardeal Leme",
    letter: "L",
    kind: "Salas de aula e laboratórios",
    rooms: ["L112", "L206", "L318", "LIENG"],
    x: 44,
    y: 150,
    w: 128,
    h: 96,
    via: [
      [150, 262],
      [108, 246],
    ],
    walkMinutes: 4,
  },
  {
    id: "frings",
    name: "Cardeal Frings",
    letter: "F",
    kind: "Engenharia",
    rooms: ["F309", "F402"],
    x: 196,
    y: 160,
    w: 116,
    h: 86,
    via: [
      [206, 268],
      [254, 250],
    ],
    walkMinutes: 5,
  },
  {
    id: "kennedy",
    name: "Kennedy",
    letter: "K",
    kind: "Salas de aula",
    rooms: ["K102", "K210"],
    x: 210,
    y: 62,
    w: 102,
    h: 74,
    via: [
      [206, 268],
      [262, 200],
      [262, 140],
    ],
    walkMinutes: 8,
  },
  {
    id: "rdc",
    name: "RDC",
    letter: "R",
    kind: "Reitor Dom Cândido - salas e auditórios",
    rooms: ["R204", "Auditório RDC"],
    x: 46,
    y: 52,
    w: 130,
    h: 80,
    via: [
      [150, 262],
      [100, 200],
      [100, 146],
    ],
    walkMinutes: 9,
  },
  {
    id: "franca",
    name: "Padre Leonel Franca",
    letter: "A",
    kind: "Auditório e administração",
    rooms: ["Auditório Padre Anchieta"],
    x: 40,
    y: 350,
    w: 128,
    h: 78,
    via: [
      [150, 320],
      [104, 344],
    ],
    walkMinutes: 3,
  },
  {
    id: "vila",
    name: "Vila dos Diretórios",
    letter: "V",
    kind: "Alimentação e diretórios",
    rooms: ["Restaurantes", "Praça de alimentação"],
    x: 196,
    y: 340,
    w: 120,
    h: 74,
    via: [
      [206, 326],
      [252, 340],
    ],
    walkMinutes: 4,
  },
  {
    id: "biblioteca",
    name: "Biblioteca Central",
    letter: "B",
    kind: "Acervo e salas de estudo",
    rooms: ["Acervo", "Salas de estudo"],
    x: 190,
    y: 436,
    w: 124,
    h: 62,
    via: [
      [206, 326],
      [250, 420],
    ],
    walkMinutes: 6,
  },
  {
    id: "ginasio",
    name: "Ginásio",
    letter: "G",
    kind: "Esportes",
    rooms: ["Quadra", "Vestiários"],
    x: 44,
    y: 446,
    w: 120,
    h: 58,
    via: [
      [150, 320],
      [104, 430],
    ],
    walkMinutes: 7,
  },
];

export function buildingById(id: string) {
  return BUILDINGS.find((b) => b.id === id);
}

export function findRoom(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return undefined;
  for (const b of BUILDINGS) {
    const room = b.rooms.find((r) => r.toLowerCase() === q);
    if (room) return { building: b, room };
  }
  return undefined;
}

export type SearchResult = {
  title: string;
  subtitle: string;
  buildingId: string;
  room?: string;
};

export function searchCampus(query: string): SearchResult[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const out: SearchResult[] = [];
  for (const b of BUILDINGS) {
    if (b.name.toLowerCase().includes(q) || b.kind.toLowerCase().includes(q)) {
      out.push({ title: b.name, subtitle: b.kind, buildingId: b.id });
    }
    for (const r of b.rooms) {
      if (r.toLowerCase().includes(q)) {
        out.push({ title: r, subtitle: b.name, buildingId: b.id, room: r });
      }
    }
  }
  return out.slice(0, 8);
}

export function classByRoom(room: string) {
  return CLASSES.find((c) => c.room.toLowerCase() === room.toLowerCase());
}

export const COURSES = [
  "Engenharia de Computação",
  "Engenharia de Produção",
  "Engenharia Civil",
  "Engenharia Elétrica",
  "Engenharia Mecânica",
  "Ciência da Computação",
  "Sistemas de Informação",
  "Design",
  "Direito",
  "Administração",
  "Psicologia",
  "Comunicação Social",
  "Relações Internacionais",
  "Arquitetura e Urbanismo",
];

export type Notice = {
  id: string;
  kind: "sala" | "cancelamento" | "recado";
  title: string;
  message: string;
  meta: string;
  classId?: string;
  newRoom?: string;
};

export const NOTICES: Notice[] = [
  {
    id: "n1",
    kind: "sala",
    title: "Mudança de sala — ENG1000",
    message: "A aula de hoje foi transferida da sala F402 para a sala F309, no 3º andar do Cardeal Frings.",
    meta: "Há 12 minutos • Cláudia Menezes",
    classId: "eng1000-qua",
    newRoom: "F309",
  },
  {
    id: "n2",
    kind: "cancelamento",
    title: "Aula cancelada — LET1010",
    message: "A aula de quinta-feira (07:00) está cancelada. Reposição será marcada pelo professor.",
    meta: "Há 2 horas • Beatriz Lins",
    classId: "let1010-qui",
  },
  {
    id: "n3",
    kind: "recado",
    title: "Recado do professor — ENG4021",
    message: "Tragam o notebook com o ambiente configurado para a entrega parcial do projeto integrado.",
    meta: "Ontem, 18:30 • Luís Fernando Bicalho",
    classId: "eng4021-sex",
  },
];

export const DEFAULT_STUDENT = {
  name: "Lucas Silveira de Alencar",
  registration: "2110482",
  course: "Engenharia de Computação",
  email: "lucas.alencar@aluno.puc-rio.br",
  passwordUpdated: "Atualizada há 3 meses",
};

export function initialsOf(name: string) {
  const parts = name.trim().split(/\s+/).filter((p) => p.length > 2);
  const first = parts[0]?.[0] ?? "M";
  const last = parts.length > 1 ? (parts[parts.length - 1]?.[0] ?? "") : "";
  return (first + last).toUpperCase();
}

export function todayWeekday(): Weekday {
  const map: Record<number, Weekday> = { 1: "SEG", 2: "TER", 3: "QUA", 4: "QUI", 5: "SEX" };
  return map[new Date().getDay()] ?? "QUA";
}
