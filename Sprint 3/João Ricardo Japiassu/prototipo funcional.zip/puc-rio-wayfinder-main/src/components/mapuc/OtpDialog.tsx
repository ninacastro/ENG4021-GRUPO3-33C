import { ArrowRight, Clock, Mail } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export function OtpDialog({
  open,
  onOpenChange,
  email,
  onConfirmed,
  onChangeEmail,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  email: string;
  onConfirmed: () => void;
  onChangeEmail: () => void;
}) {
  const [digits, setDigits] = useState(["", "", "", ""]);
  const [seconds, setSeconds] = useState(60);
  const refs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (!open) return;
    setDigits(["", "", "", ""]);
    setSeconds(60);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const id = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [open]);

  function setDigit(index: number, value: string) {
    const v = value.replace(/\D/g, "").slice(-1);
    setDigits((prev) => {
      const next = [...prev];
      next[index] = v;
      return next;
    });
    if (v && index < 3) refs.current[index + 1]?.focus();
  }

  function confirm() {
    if (digits.some((d) => !d)) {
      toast.error("Digite os 4 dígitos do código.");
      return;
    }
    onConfirmed();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[380px] rounded-3xl p-7">
        <DialogTitle className="sr-only">Código enviado por e-mail</DialogTitle>
        <div className="flex flex-col items-center text-center">
          <div className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-blue-soft">
            <Mail className="h-7 w-7 text-brand-blue" />
          </div>
          <h2 className="mt-5 text-2xl font-extrabold leading-tight text-navy">
            CÓDIGO ENVIADO
            <br />
            POR E-MAIL
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">Insira o código de 4 dígitos enviado para</p>
          <p className="mt-1 rounded-lg bg-brand-blue-soft px-3 py-1 text-sm font-medium text-navy">{email}</p>

          <div className="mt-5 flex gap-3">
            {digits.map((d, i) => (
              <input
                key={i}
                ref={(el) => {
                  refs.current[i] = el;
                }}
                value={d}
                inputMode="numeric"
                aria-label={`Dígito ${i + 1}`}
                onChange={(e) => setDigit(i, e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Backspace" && !digits[i] && i > 0) refs.current[i - 1]?.focus();
                }}
                className={cn(
                  "h-16 w-14 rounded-2xl border-2 bg-muted text-center text-2xl font-bold text-navy outline-none",
                  d ? "border-brand-blue bg-card" : "border-border",
                  "focus:border-brand-blue focus:bg-card",
                )}
              />
            ))}
          </div>

          <p className="mt-4 flex items-center gap-2 rounded-full bg-muted px-4 py-2 text-base font-bold text-navy">
            <Clock className="h-4 w-4 text-brand-blue" />
            {seconds}
            <span className="font-normal text-muted-foreground">segundos</span>
          </p>

          <p className="mt-4 text-sm text-muted-foreground">
            Não recebeu?{" "}
            <button
              type="button"
              onClick={() => {
                setSeconds(60);
                toast.success("Novo código enviado.");
              }}
              className="font-bold text-brand-blue"
            >
              Reenviar código
            </button>
          </p>

          <button
            type="button"
            onClick={confirm}
            className="mt-5 flex w-full items-center justify-center gap-3 rounded-2xl bg-navy py-4 text-base font-bold tracking-wide text-primary-foreground"
          >
            CONFIRMAR CÓDIGO <ArrowRight className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={onChangeEmail}
            className="mt-4 text-sm font-bold tracking-wide text-muted-foreground"
          >
            ALTERAR E-MAIL INFORMADO
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
