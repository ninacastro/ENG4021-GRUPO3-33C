import { BUILDINGS, YOU_ARE_HERE, type Building } from "@/lib/mapuc-data";
import { cn } from "@/lib/utils";

export function routePointsTo(b: Building): [number, number][] {
  return [YOU_ARE_HERE, ...b.via, [b.x + b.w / 2, b.y + b.h / 2]];
}

export function CampusMap({
  selectedId,
  onSelect,
  route,
  className,
}: {
  selectedId?: string;
  onSelect: (id: string) => void;
  route?: [number, number][];
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 360 520"
      className={cn("h-full w-full", className)}
      role="img"
      aria-label="Mapa do campus da PUC-Rio"
    >
      <rect width="360" height="520" fill="var(--teal-soft)" />
      {/* áreas verdes */}
      <circle cx="330" cy="290" r="52" fill="var(--surface)" />
      <circle cx="20" cy="300" r="44" fill="var(--surface)" />
      {/* vias principais */}
      <path
        d="M176 520 V40 M20 262 H340 M20 330 H340"
        stroke="white"
        strokeWidth="16"
        strokeLinecap="round"
        fill="none"
      />

      {BUILDINGS.map((b) => {
        const active = b.id === selectedId;
        return (
          <g
            key={b.id}
            onClick={() => onSelect(b.id)}
            className="cursor-pointer"
            role="button"
            aria-label={b.name}
          >
            <rect
              x={b.x}
              y={b.y}
              width={b.w}
              height={b.h}
              rx="12"
              fill={active ? "var(--navy)" : "white"}
              stroke={active ? "var(--teal)" : "var(--border)"}
              strokeWidth={active ? 3 : 1.5}
            />
            <text
              x={b.x + b.w / 2}
              y={b.y + b.h / 2 - 4}
              textAnchor="middle"
              fontSize="17"
              fontWeight="800"
              fill={active ? "var(--teal)" : "var(--navy)"}
            >
              {b.letter}
            </text>
            <text
              x={b.x + b.w / 2}
              y={b.y + b.h / 2 + 13}
              textAnchor="middle"
              fontSize="9.5"
              fontWeight="600"
              fill={active ? "white" : "var(--navy-muted)"}
            >
              {b.name}
            </text>
          </g>
        );
      })}

      {route && route.length > 1 ? (
        <>
          <polyline
            points={route.map((p) => p.join(",")).join(" ")}
            fill="none"
            stroke="var(--navy)"
            strokeWidth="7"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity="0.18"
          />
          <polyline
            className="route-dash"
            points={route.map((p) => p.join(",")).join(" ")}
            fill="none"
            stroke="var(--teal-dark)"
            strokeWidth="4.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      ) : null}

      <g>
        <circle cx={YOU_ARE_HERE[0]} cy={YOU_ARE_HERE[1]} r="11" fill="var(--teal)" opacity="0.3" />
        <circle cx={YOU_ARE_HERE[0]} cy={YOU_ARE_HERE[1]} r="6" fill="var(--teal-dark)" stroke="white" strokeWidth="2.5" />
      </g>
    </svg>
  );
}
