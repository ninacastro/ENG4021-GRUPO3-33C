import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  ArrowLeft,
  Bell,
  Building2,
  CalendarDays,
  CircleHelp,
  Home,
  Map as MapIcon,
  Menu,
  Monitor,
  Smartphone,
  Star,
  UserRound,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useApp } from "@/lib/app-state";
import { initialsOf } from "@/lib/mapuc-data";
import { MapucMark } from "./Logo";

export function DeviceToggle() {
  const { device, setDevice } = useApp();
  return (
    <div className="fixed right-3 top-3 z-50 flex items-center gap-1 rounded-full border border-border bg-card p-1 shadow-sm">
      {(
        [
          { key: "mobile" as const, icon: Smartphone, label: "Celular" },
          { key: "desktop" as const, icon: Monitor, label: "Computador" },
        ]
      ).map(({ key, icon: Icon, label }) => (
        <button
          key={key}
          type="button"
          aria-label={label}
          onClick={() => setDevice(key)}
          className={cn(
            "grid h-8 w-8 place-items-center rounded-full transition-colors",
            device === key ? "bg-navy text-primary-foreground" : "text-muted-foreground hover:bg-muted",
          )}
        >
          <Icon className="h-4 w-4" />
        </button>
      ))}
    </div>
  );
}

/** Moldura do app: celular centralizado ou visão ampla no desktop. */
export function AppFrame({ children, requireAuth = true }: { children: ReactNode; requireAuth?: boolean }) {
  const { device, hydrated, signedIn } = useApp();
  const navigate = useNavigate();

  useEffect(() => {
    if (hydrated && requireAuth && !signedIn) {
      navigate({ to: "/", replace: true });
    }
  }, [hydrated, requireAuth, signedIn, navigate]);

  return (
    <div className="min-h-screen w-full bg-muted/40 px-0 py-0 md:px-4 md:py-6">
      <DeviceToggle />
      <div
        className={cn(
          "mx-auto flex min-h-screen w-full flex-col bg-surface md:min-h-[calc(100vh-3rem)] md:overflow-hidden md:rounded-[2rem] md:border md:border-border md:shadow-xl",
          device === "mobile" ? "max-w-[440px]" : "max-w-[1080px]",
        )}
      >
        {children}
      </div>
    </div>
  );
}

export type AppPath =
  | "/"
  | "/inicio"
  | "/mapa"
  | "/horario"
  | "/avisos"
  | "/cadastro"
  | "/perfil"
  | "/perfil/dados"
  | "/perfil/senha"
  | "/perfil/sair";

export function ScreenHeader({
  title,
  back = "/inicio",
  right,
}: {
  title: string;
  back?: AppPath;
  right?: ReactNode;
}) {
  return (
    <header className="sticky top-0 z-20 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-card px-4 py-4">
      <Link
        to={back}
        aria-label="Voltar"
        className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-border text-navy hover:bg-muted"
      >
        <ArrowLeft className="h-5 w-5" />
      </Link>
      <h1 className="truncate text-xl font-bold text-navy">{title}</h1>
      <div className="shrink-0">{right}</div>
    </header>
  );
}

const drawerItems = [
  { to: "/inicio", label: "Início", icon: Home },
  { to: "/mapa", label: "Mapa do campus", icon: Building2 },
  { to: "/horario", label: "Horário de aulas", icon: CalendarDays },
  { to: "/avisos", label: "Avisos e recados", icon: Bell },
  { to: "/perfil", label: "Perfil", icon: UserRound },
] as const;

export function MenuDrawer() {
  const [open, setOpen] = useState(false);
  const { student, unreadCount } = useApp();
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger
        aria-label="Abrir menu"
        className="flex flex-col items-center gap-1 rounded-xl px-2 py-1 text-navy hover:bg-muted"
      >
        <Menu className="h-6 w-6" />
        <span className="text-[10px] font-bold tracking-widest">MENU</span>
      </SheetTrigger>
      <SheetContent side="left" className="w-[280px] bg-card p-0">
        <SheetTitle className="sr-only">Menu de navegação</SheetTitle>
        <div className="flex items-center gap-3 border-b border-border px-5 py-5">
          <div className="grid h-11 w-11 place-items-center rounded-full bg-navy text-sm font-bold text-primary-foreground">
            {initialsOf(student.name)}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-navy">{student.name}</p>
            <p className="text-xs text-muted-foreground">Matrícula: {student.registration}</p>
          </div>
        </div>
        <nav className="flex flex-col p-3">
          {drawerItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
              activeProps={{ className: "bg-teal-soft text-teal-dark" }}
              className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-navy hover:bg-muted"
            >
              <item.icon className="h-5 w-5" />
              <span className="flex-1">{item.label}</span>
              {item.to === "/avisos" && unreadCount > 0 ? (
                <span className="grid h-5 min-w-5 place-items-center rounded-full bg-danger px-1 text-[11px] font-bold text-primary-foreground">
                  {unreadCount}
                </span>
              ) : null}
            </Link>
          ))}
        </nav>
        <div className="mt-auto space-y-2 px-5 py-4 text-xs text-muted-foreground">
          <p className="flex items-center gap-2">
            <Star className="h-4 w-4" /> Favoritos do campus
          </p>
          <p className="flex items-center gap-2">
            <CircleHelp className="h-4 w-4" /> Ajuda e suporte
          </p>
          <p>v2.4.1</p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { unreadCount } = useApp();
  const items = [
    { to: "/mapa", label: "MAPA", icon: MapIcon },
    { to: "/horario", label: "HORÁRIO", icon: CalendarDays },
  ] as const;

  return (
    <nav className="sticky bottom-0 z-20 grid grid-cols-2 items-center gap-2 border-t border-border bg-card px-6 py-3">
      {items.map((item) => {
        const active = pathname.startsWith(item.to);
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "relative flex flex-col items-center gap-1 rounded-2xl py-2 transition-colors",
              active ? "bg-muted text-navy" : "text-muted-foreground hover:text-navy",
            )}
          >
            <item.icon className="h-6 w-6" />
            <span className="text-xs font-bold tracking-wide">{item.label}</span>
            {item.to === "/horario" && unreadCount > 0 ? (
              <span className="absolute right-6 top-1 h-2 w-2 rounded-full bg-teal-dark" />
            ) : null}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppTopBar({ subtitle, back = true }: { subtitle: string; back?: boolean }) {
  const { student, unreadCount } = useApp();
  return (
    <header className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-card px-4 py-3">
      <div className="flex shrink-0 items-center gap-2">
        {back ? (
          <Link
            to="/inicio"
            aria-label="Voltar ao menu principal"
            className="grid h-9 w-9 place-items-center rounded-full border border-border text-navy hover:bg-muted"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
        ) : null}
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-navy">
          <MapucMark className="h-7 w-7" />
        </div>
      </div>
      <div className="min-w-0">
        <p className="truncate text-xl font-extrabold">
          <span className="text-teal-dark">Ma</span>
          <span className="text-navy">PUC</span>
        </p>
        <p className="truncate text-xs text-muted-foreground">{subtitle}</p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <Link
          to="/avisos"
          aria-label="Avisos"
          className="relative grid h-10 w-10 place-items-center rounded-full border border-border text-navy hover:bg-muted"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 ? (
            <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-primary-foreground">
              {unreadCount}
            </span>
          ) : null}
        </Link>
        <Link
          to="/perfil"
          aria-label="Perfil"
          className="grid h-10 w-10 place-items-center rounded-full bg-muted text-sm font-bold text-navy"
        >
          {initialsOf(student.name)}
        </Link>
      </div>
    </header>
  );
}
