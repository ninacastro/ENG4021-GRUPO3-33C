import { cn } from "@/lib/utils";

/** Pino de localização com a torre da capela da PUC-Rio. */
export function MapucMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 76" className={cn("h-10 w-10", className)} aria-hidden="true">
      {/* corpo do pino */}
      <path
        d="M32 3c15.5 0 27 11.4 27 25.8 0 17.6-20.6 35.8-25.3 39.7a2.7 2.7 0 0 1-3.4 0C25.6 64.6 5 46.4 5 28.8 5 14.4 16.5 3 32 3Z"
        fill="var(--navy)"
      />
      {/* aba teal à direita */}
      <path d="M43 12h13v26.5c0 6-2.6 11.8-6.1 17V16a4 4 0 0 0-4-4h-2.9Z" fill="var(--teal)" />
      {/* torre da capela */}
      <path d="M32 3.5 26.5 9v6h11V9L32 3.5Z" fill="white" opacity="0.95" />
      <rect x="31.2" y="0" width="1.6" height="5" fill="white" />
      <rect x="29" y="1.4" width="6" height="1.5" fill="white" />
      <rect x="28" y="10.5" width="1.6" height="4" fill="var(--navy)" />
      <rect x="31.2" y="10.5" width="1.6" height="4" fill="var(--navy)" />
      <rect x="34.4" y="10.5" width="1.6" height="4" fill="var(--navy)" />
      {/* arco / entrada */}
      <path
        d="M24 46V32a8 8 0 0 1 16 0v18h-6V32a2 2 0 0 0-4 0v14h-6Z"
        fill="white"
      />
      {/* sombra */}
      <ellipse cx="32" cy="71" rx="16" ry="3.2" fill="var(--navy)" opacity="0.12" />
    </svg>
  );
}

export function MapucWordmark({ className, subtitle = true }: { className?: string; subtitle?: boolean }) {
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <MapucMark className="h-16 w-16" />
      <p className="mt-1 text-4xl font-extrabold tracking-tight">
        <span className="text-teal-dark">Ma</span>
        <span className="text-navy">PUC</span>
      </p>
      {subtitle ? (
        <div className="mt-1 flex items-center gap-2">
          <span className="h-px w-5 bg-teal-dark" />
          <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-navy">
            Encontre seu caminho na PUC-Rio
          </p>
          <span className="h-px w-5 bg-teal-dark" />
        </div>
      ) : null}
    </div>
  );
}
